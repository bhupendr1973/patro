const cacheName = "calendar-v1";
const cacheUrls = [
  "./",

  "./data/solar_ns_events.json",

  "./data/sun.json",
  "./data/rashi.json",

  "./data/2076_detailed.json",
  "./data/2077_detailed.json",
  "./data/2078_detailed.json",
  "./data/2079_detailed.json",
  "./data/2080_detailed.json",
  "./data/2081_detailed.json",
  "./data/international_events.json",
  "./data/national_events.json",
  "./data/other_json.json",
  "./data/public_holidays.json",
  "./data/public1_holidays.json",
  "./data/public2_holidays.json",
  "./data/public3_holidays.json",
  "./data/public4_holidays.json",

  "./data/muhoortta.json",
  "./assets/vvvv.gif",
  "./assets/poster.jpg",
  "./assets/favicon.svg",
  "./assets/brihat_calendar.png",
  "https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css",
  "./css/index.css",
  "./css/panchang1.css",
  "./css/panchang2.css",
  "./css/index_details.css",
  "./css/index_cal_conv.css",
  "./css/public_holidays.css",
  "./css/muhoortta.css",
  "./css/parvas.css",
  "./css/settings.css",
  "./css/panchang.css",
  "./css/check-box.css",
  "./css/darkmode.css",

  "./css/music-model.css",
  "./css/settings-model.css",

  "./js/NS.js",
  "./js/NS_AD.js",
  "./js/NS_BS.js",
  "./js/AD_BS.js",
  "./js/index.js",
  "./js/index_cal_conv.js",
  "./js/index_details.js",
  "./js/muhoortta.js",
  "./js/parvas.js",
  "./js/public_holidays.js",
  "./js/public1_holidays.js",
  "./js/public2_holidays.js",
  "./js/public3_holidays.js",
  "./js/public4_holidays.js",
  "./js/swipe_actions.js",
  "./js/darkmode.js",
  "./js/panchang.js",

  "./index.html",
];

// Installing the Service Worker
self.addEventListener("install", async (event) => {
  try {
    const cache = await caches.open(cacheName);
    await cache.addAll(cacheUrls);
  } catch (error) {
    console.error("Service Worker installation failed:", error);
  }
});

// Fetching resources
self.addEventListener("fetch", (event) => {
  event.respondWith(
    (async () => {
      const cache = await caches.open(cacheName);

      try {
        const cachedResponse = await cache.match(event.request);
        if (cachedResponse) {
          console.log("cachedResponse: ", event.request.url);
          return cachedResponse;
        }

        const fetchResponse = await fetch(event.request);
        if (fetchResponse) {
          console.log("fetchResponse: ", event.request.url);
          await cache.put(event.request, fetchResponse.clone());
          return fetchResponse;
        }
      } catch (error) {
        console.log("Fetch failed: ", error);
        const cachedResponse = await cache.match("index.html");
        return cachedResponse;
      }
    })()
  );
});
