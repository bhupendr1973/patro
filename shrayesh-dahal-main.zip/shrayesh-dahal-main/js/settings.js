

let gear = document.getElementById("settings");
let setting_pane = document.getElementById("settings_pane");
let setting_pane_dismiss = document.getElementById("settings_dismiss");

gear.addEventListener('click', function(event) {
    setting_pane.classList.toggle('active');
});

setting_pane_dismiss.addEventListener('click', function(event) {
    setting_pane.classList.toggle('active');
});

function toggle_all() {
    let check_all = document.getElementById('check_all').checked;

    if (check_all) {
        document.getElementById('check_darkmode').checked = true;
        document.getElementById('check_info_box').checked = true;
        document.getElementById('check_muhoortta_box').checked = true;
        document.getElementById('check_darkModeToggle').checked = true;
        document.getElementById('check_mymusic').checked = true;
        document.getElementById('check_date_jumper').checked = true;
    }
    else {
        document.getElementById('check_darkModeToggle').checked = false;
        document.getElementById('check_mymusic').checked = false;
        document.getElementById('check_muhoortta_box').checked = false;
        document.getElementById('check_info_box').checked = false;
        document.getElementById('check_darkmode').checked = false;
       
        document.getElementById('check_date_jumper').checked = false;
    }
    trigger_all_event();
}

function toggle_info_box() {
    let check_info_box = document.getElementById('check_info_box');

    if(check_info_box.checked == true) {
        document.getElementById('parvas').style.display = "block";
    }
    else {
        document.getElementById('parvas').style.display = "none";
    }
    console.info("Preferences (Show Event Info Box) set to: ", check_info_box.checked);
}

function toggle_muhoortta_box() {
    let check_muhoortta_box = document.getElementById('check_muhoortta_box');

    if(check_muhoortta_box.checked == true) {
        document.getElementById('muhoortta_box').style.display = "flex";
        show_muhoortta_box_session = true;
    }
    else {
        document.getElementById('muhoortta_box').style.display = "none";
        show_muhoortta_box_session = true;
    }
    console.info("Preferences (Show Muhoortta Box) set to: ", check_muhoortta_box.checked);
}

function toggle_date_jumper() {
    let check_date_jumper = document.getElementById('check_date_jumper');

    if(check_date_jumper.checked == true) {
        document.getElementById('brihat_calendar_date_jumper').style.display = "flex";
    }
    else {
        document.getElementById('brihat_calendar_date_jumper').style.display = "none";
    }
    console.info("Preferences (Show Date Jumper) set to: ", check_date_jumper.checked);
}

function toggle_darkmode() {
    let check_darkmode = document.getElementById('check_darkmode');

    if(check_darkmode.checked == true) {
        document.body.classList.add('darkmode');
        show_darkmode = true;
    }
    else {
        document.body.classList.remove('darkmode');
        show_darkmode = true;
    }
    console.info("Preferences (Show Muhoortta Box) set to: ", check_darkmode.checked);
}

function toggle_darkModeToggle() {
    let check_darkModeToggle = document.getElementById('check_darkModeToggle');

    if(check_darkModeToggle.checked == true) {
        document.querySelector('#dark-mode-toggle').style.display = "flex";
        show_darkmode = true;
    }
    else {
        document.querySelector('#dark-mode-toggle').style.display = "none";
        show_darkmode = false;
    }
    console.info("Preferences (Show Muhoortta Box) set to: ", check_darkModeToggle.checked);
}

function toggle_mymusic() {
    let check_mymusic = document.getElementById('check_mymusic');

    if(check_mymusic.checked == true) {
        document.querySelector('#mymusic').style.display = "flex";
        show_mymusic = true;
    }
    else {
        document.querySelector('#mymusic').style.display = "none";
        show_mymusic = false;
    }
    console.info("Preferences (Show Muhoortta Box) set to: ", check_mymusic.checked);
}
function toggle_invert_color() {
    let invert_color = document.getElementById('invert_color');

    if(invert_color.checked == true) {
        document.getElementsByTagName('html')[0].style.filter = "invert(125%)";
    }
    else {
        document.getElementsByTagName('html')[0].style.filter = "none";
    }
    console.info("Preferences (Invert Color) set to: ", invert_color.checked);
}

function toggle_pakshya_lang(){
    let lunar_month_info = document.getElementById("lunar_details");
    let check_pakshya_lang = document.getElementById("check_pakshya_lang");

    if(check_pakshya_lang.checked == true) {
        if(!lunar_month_info.classList.contains('pakshya-details-nep')) {
            lunar_month_info.click();
        }
    }
    else {
        if(lunar_month_info.classList.contains('pakshya-details-nep')) {
            lunar_month_info.classList.remove('pakshya-details-nep');
            lunar_month_info.click();
        }
    }
    console.info("Preferences (Lunar Month Info Lang) set to: ", check_pakshya_lang.checked ? "Nepali" : "Default");
}
    function trigger_all_event() {
    toggle_darkmode();
    toggle_mymusic();
    toggle_info_box();
    toggle_muhoortta_box();
    toggle_darkModeToggle();
    toggle_invert_color();
    toggle_pakshya_lang();
}
var config = [];
const default_config = [true, false, false, false, true, false, false, false, false];


// parvas info box lang: values (np, en): [BS, INTERNAT, SNS, NAT, OTHER]
const parvas_info_box_lang_default = ["np", "en", "np", "np", "en"];
let parvas_info_box_lang = [];

function save_current_config() {
    config[9] = document.getElementById('check_darkmode').checked;
    config[1] = document.getElementById('check_info_box').checked;
    config[4] = document.getElementById('check_date_jumper').checked;
    config[5] = document.getElementById('invert_color').checked;
    config[6] = document.getElementById('check_pakshya_lang').checked;
   
    config[8] = document.getElementById('check_muhoortta_box').checked;
    config[10] = document.getElementById('check_darkModeToggle').checked;
    config[11] = document.getElementById('check_mymusic').checked;
    localStorage.setItem("config", JSON.stringify(config));
    
    parvas_info_box_lang[0] = 'np';
    parvas_info_box_lang[4] = document.getElementById('check_lang_info_other').checked ? 'np' : 'en';
    localStorage.setItem("info_box_lang", JSON.stringify(parvas_info_box_lang));
    parvas_info_box_lang_session = parvas_info_box_lang;
    console.info("Current Event Info Language Preferences Saved Successfully.");

    console.info("Current Preferences Saved Successfully.");
    swal("Success!", "Current Config Saved", "success");
}

function load_config(def = false) {
    if (localStorage.config == null) {
        config = default_config;
        localStorage.setItem("config", JSON.stringify(default_config));
    }
    else {
        config = JSON.parse(localStorage.config);
    }

    if (localStorage.info_box_lang == null) {
        parvas_info_box_lang_session = parvas_info_box_lang_default;
        localStorage.setItem("info_box_lang", JSON.stringify(parvas_info_box_lang_default));
    }

    else {
        parvas_info_box_lang_session = JSON.parse(localStorage.info_box_lang);
    }

    if(def == true) {
        localStorage.setItem("config", JSON.stringify(default_config));
        console.info("No User Preferences Found: Default Loaded and Saved.");
        localStorage.setItem("info_box_lang", JSON.stringify(parvas_info_box_lang_default));
        console.info("No Language Preferences Found: Default Loaded and Saved.");

        load_config();
    }
    
    else if (config == null) {
        localStorage.setItem("config", JSON.stringify(default_config));
        console.info("No User Preferences Found: Default Loaded and Saved.");
        load_config();
    }

    else if (parvas_info_box_lang == null) {
        localStorage.setItem("info_box_lang", JSON.stringify(parvas_info_box_lang_default));
        console.info("No Language Preferences Found: Default Loaded and Saved.");
        load_config();
    }

    else {
        document.getElementById('check_darkmode').checked = config[9];
        document.getElementById('check_info_box').checked = config[1];
        document.getElementById('check_date_jumper').checked = config[4];
        document.getElementById('invert_color').checked = config[5];
        document.getElementById('check_pakshya_lang').checked = config[6];
        document.getElementById('check_muhoortta_box').checked = config[8];
        document.getElementById('check_mymusic').checked = config[11];
        document.getElementById('check_darkModeToggle').checked = config[10];
       
       
        document.getElementById("check_lang_info_other").checked = parvas_info_box_lang_session[4] == "np";

        trigger_all_event();
        console.info("User Preferences Loaded Successfully.");
    }
}

function reset_default_config() {
    swal({
        title: "Are you sure?",
        text: "Restore Default Config?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
            load_config(true);
            console.info("Default User Preferences Loaded Successfully.");
            swal("Success!", "Default Config Restored", "success", {icon: "success"});
        }
        else {
          swal("Aborted");
          console.info("Preferences Reset Operation Cancelled");
        }
      });
}

load_config();

document.getElementById("setting_pane_author").innerHTML = "<i class='fa fa-solid fa-copyright'></i><br />";
document.getElementById("setting_pane_author").innerHTML += " "  + "  " + AD_TODAY_YEAR + " AD | वि. सं. " + arabic_number_to_nepali(bs_today_year);
document.getElementById("setting_pane_author").innerHTML += "<br /> Develop by Bhupendra Dahal<br<br /><br />";
